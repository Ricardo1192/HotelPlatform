export class UserModel {
    firstName: String;
    secondName: String;
    firstLastname: String;
    secondLastname: String;
    email: String;
    password: String;
    birthDate: String;
    address: String;
    cellphone: String;
    isLogged: boolean = false;
}